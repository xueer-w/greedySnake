import pygame
import sys
 
# 初始化Pygame
pygame.init()
 
# 设置屏幕尺寸
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("流水灯效果")
 
# 定义颜色
colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0), (255, 0, 255)]  # 红、绿、蓝、黄、紫
 
light_positions = [100, 200, 300, 400, 500]  # x坐标
current_color_index = 0  # 初始颜色索引
move_direction = 1  
 
running = True
clock = pygame.time.Clock()
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    current_color_index = (current_color_index + move_direction) % len(colors)
 
   
    screen.fill((0, 0, 0)) 
 
    for i, pos in enumerate(light_positions):
        color_index = (current_color_index - i * move_direction) % len(colors)
        color = colors[color_index]
        pygame.draw.circle(screen, color, (pos, screen_height // 2), 20)  # 在每个位置绘制一个圆点
 
    pygame.display.flip()
 
    clock.tick(2)
 
pygame.quit()
sys.exit()