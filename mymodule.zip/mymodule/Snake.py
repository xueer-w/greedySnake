
import pygame
import copy
import numpy as np
import imageio as io
from mymodule.tileMap import TileMap
import os
import  pygame.freetype as freetype

from random  import randint 
class Direction:
    right=0
    down=1
    left=2
    up=3


cantsee=250


def  get_images(path,size=(cantsee,cantsee)):
    #[print(f.shape)  for f in  io.mimread(path)]
    res=[pygame.image.frombuffer(f,f.shape[0:-1],  "RGB" if  f.shape[-1]==3 else "RGBA"  ).convert() for f in  io.mimread(path)]
    res=[pygame.transform.scale(f,size)  for f in res]
    [(f.set_alpha(200),f.set_colorkey((0,0,0)))  for f in res]

    return res

class Snake:
    def __init__(self,header="./data/head.png",body="./data/body.png",tail="./data/tail.png",ceilSize=25,map=None,surface=None,animate=None):
        self.header=pygame.image.load(header)
        self.animate=animate
        self.header_rect=self.header.get_rect()
        self.body=pygame.image.load(body)
        self.body_rect=self.body.get_rect()
        self.tail=pygame.image.load(tail)
        self.tail_rect=self.tail.get_rect()
        self.parts=[]
        self.cell_size=ceilSize
        self.headers=[pygame.Surface((self.cell_size*2,self.cell_size))   for i in  range(4) ]
        
        [ self.headers[i].blit(self.header,(0,0),(i*self.cell_size*2,0,self.cell_size*2,self.cell_size))   for i in range(4) ]
        self.tails=[pygame.Surface((self.cell_size*2,self.cell_size))   for i in  range(4) ]
        [ self.tails[i].blit(self.tail,(0,0),(i*self.cell_size*2,0,self.cell_size*2,self.cell_size))   for i in range(4) ]

        self.step_count=0
        self.current_dir=Direction.right
        self.dir_step=[0]*4
        self.map=map
        self.surface=surface

        self.die=pygame.mixer.Sound("./data/defeated.mp3")

        rd_pos=np.array([randint(1,self.map.col-2),randint(1,self.map.row-2)])
        rd_pos=np.array((self.map.col//2,self.map.row//2)) 

        which=randint(0,3)
        nw_h=pygame.Surface((self.cell_size,self.cell_size))
        nw_h.blit(self.headers[which],(0,0),(self.dir_step[which]*self.cell_size,0,self.cell_size,self.cell_size))
        self.dir_step[which]+=1
        self.dir_step[which]%=2
        self.current_dir=which
        self.parts.append((rd_pos,nw_h,which))
        self.dir_bias=np.array([(1,0),(0,1),(-1,0),(0,-1)])

        self.gifs=[ get_images("./data/"+p) for p in os.listdir("./data")   if p.startswith("good")]

        self.score=0
        self.font=freetype.Font('./data/stsong.ttf',50)
        self.unbelivable=pygame.mixer.Sound("./data/unbelivable.mp3")
        self.eate=pygame.mixer.Sound("./data/eate.mp3")

        self.last=0
        self.max_last=10
        self.ready=pygame.mixer.Sound("./data/ready.mp3")

    def   test(self,surface,step):
            #surface.blit(self.header,(15*25,(step%15)*25),(1*50+(step%2)*25,0,25,25))
            
            surface.blit(self.header2,(15*25,(step%15)*25))

            surface.blit(self.body,(15*25,((step-1)%15)*25))
            surface.blit(self.body,(15*25,((step-2)%15)*25))
            surface.blit(self.tail,(15*25,((step-3)%15)*25))
          

            red=pygame.image.load("./data/red.jpg").convert()
            red.set_colorkey((255,255,255))
            red.set_alpha(150)
            
            img_rotate=pygame.transform.rotate(red,(step%8)*45)
            img_rotate.get_rect().center=red.get_rect().center
            scale_img=pygame.transform.scale(img_rotate,(150,100))
            surface.blit(scale_img,(15*25,7*25))

    
    def step(self,dir_relative):
        nw_h=pygame.Surface((self.cell_size,self.cell_size))
        which=(self.current_dir+dir_relative)%4
        nw_h.blit(self.headers[which],(0,0),(self.dir_step[which]*self.cell_size,0,self.cell_size,self.cell_size))
        self.dir_step[which]+=1
        self.dir_step[which]%=2
        pos=copy.deepcopy(self.parts[-1][0])
        pos+=self.dir_bias[which]

        eated=False
        if self.map.can_eate(pos):
            self.handle_eate()
            self.map.take_fruit(pos)
            eated=True
        
        old=self.parts[-1][1]
        old.blit(self.body,(0,0),(self.current_dir*self.cell_size,0,self.cell_size,self.cell_size))
        self.parts.append((pos,nw_h,which))

        if not eated and  len(self.parts)>2:
            self.parts.remove(self.parts[0])
            img=self.parts[0][1]
            img.blit(self.tail,(0,0),(self.parts[0][2]*self.cell_size,0,self.cell_size,self.cell_size))


        if self.map.ifdie(pos):
            self.handle_die()
            return True

        self.current_dir=which
        self.step_count+=1

        self.handle_idl()
        
        return False
    

    def test_step(self):
        
        count=0

        dir=randint(0,3)
        pos=copy.deepcopy(self.parts[-1][0])
        which=(self.current_dir+dir)%4
        pos+=self.dir_bias[which]
        cmp_big=np.array((self.map.col-2,self.map.row-2))
        cmp_small=np.array((1,1))
        
        ps=[tuple(p) for p,img,_ in  self.parts]
        
        while np.any(pos>cmp_big)  or np.any(pos<cmp_small) or (which==((self.current_dir+2)%4))  or (tuple(pos) in ps):
            dir=randint(0,3)
            pos=copy.deepcopy(self.parts[-1][0])
            which=(self.current_dir+dir)%4
            pos+=self.dir_bias[which]

            count+=1
            if  count>100:
                count=0
                rd_pos=np.array([randint(1,self.map.col-2),randint(1,self.map.row-2)])
                which=randint(0,3)
                nw_h=pygame.Surface((self.cell_size,self.cell_size))
                nw_h.blit(self.headers[which],(0,0),(self.dir_step[which]*self.cell_size,0,self.cell_size,self.cell_size))
                self.dir_step[which]+=1
                self.dir_step[which]%=2
                self.current_dir=which
                self.parts.append((rd_pos,nw_h,which))

        return self.step(dir)




    def   human_play(self,command):
        return self.human_play_((command-self.current_dir)%4)


    def human_play_(self,dir):
        count=0
        pos=copy.deepcopy(self.parts[-1][0])
        which=(self.current_dir+dir)%4
        pos+=self.dir_bias[which]
        cmp_big=np.array((self.map.col-2,self.map.row-2))
        cmp_small=np.array((1,1))
        
        ps=[tuple(p) for p,img,_ in  self.parts]
        
        if which==((self.current_dir+2)%4):
            dir=0
            return self.step(dir)

        if np.any(pos>cmp_big)  or np.any(pos<cmp_small)   or (tuple(pos) in ps):
            self.handle_die()
            return True

        if which==((self.current_dir+2)%4):
            dir=0
        return self.step(dir)
    

    def draw(self):
        [self.surface.blit(img,pos*self.cell_size)   for pos,img ,_ in self.parts    ]
        text=f"当前游戏得分: {self.score}"

        #self.font.render_to(self.surface ((TileMap.width-100)//2+50,50), text, fgcolor=(255, 251, 0), bgcolor=(0,78,23))
        text_img,_=self.font.render(text,(255,42,78),(0,78,23))
        text_rect=text_img.get_rect()
        text_rect.center=((TileMap.width-text_rect.width)//2+150,30)
        #text_img.set_alpha(180)
        self.surface.blit(text_img,text_rect)
    
         
    def  collider(self):
        #  碰撞代码

        if  len(self.parts)>10:
            self.parts.remove(self.parts[0])
            img=self.parts[0][1]
            img.blit(self.tail,(0,0),(self.parts[0][2]*self.cell_size,0,self.cell_size,self.cell_size))


    def  handle_eate(self):
        which =randint(0,len(self.gifs)-1)
        self.animate.play(self.surface,self.gifs[which][:10],(0,
                                                         0))
        self.unbelivable.play()
        self.eate.play()
        self.score+=1
        self.last=0

        
    def  handle_die(self):
        self.die.play()
        


    def  handle_idl(self):
        self.last+=1
        if self.last>self.max_last:
            self.ready.play()
            self.last=0


class Animate:
    def __init__(self):
        self.movies=[]
        self.step_count=0
        
    def play(self,surface,frames,pos):
        self.movies.append((frames,[0],surface,pos))

    
    def  step(self):
        d=[]
        for m,p ,surface ,pos in self.movies:
            if p[0]<len(m):
                surface.blit(m[p[0]],pos)
                p[0]+=1
            else :
                 d.append((m,p,surface,pos))
        
        [  self.movies.remove(dd)   for dd in d]

        self.step_count+=1

        

        
    
   


        
        