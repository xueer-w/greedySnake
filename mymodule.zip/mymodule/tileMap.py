

import pygame
from math import ceil
import  os
import numpy as np
import random as rd
import  pygame.freetype as freetype

cantsee=250



class  TileMap:
    width,height=600,600

    def  p2r(self,pos):
        return   pos //self.col
    def  p2c(self,pos):
        return pos%self.col
    
    @staticmethod
    def set_environment(w,h):
        TileMap.width=w
        TileMap.height=h
    
    def ok(self,r,c):
        pos=np.array((r,c))
        cmp_big,cmp_small=np.array((self.row-2,self.col-2)),np.array((2,2))
        return  False if   np.any(pos > cmp_big) or np.any(pos<cmp_small) else  True

    def __init__(self,row=24,col=40,background=(0,0,0),caption="蛇年大吉！，终于靠自己动手实现了童年想玩贪吃蛇的愿望",back=None):
        self.row,self.col=row,col
        self.cellsize=max(ceil(TileMap.height//row),ceil(TileMap.width//col))
        TileMap.height,TileMap.width=self.cellsize*row,self.cellsize*col
        surface=pygame.display.set_mode((TileMap.width,TileMap.height))
        pygame.display.set_caption(caption)
        surface.fill(background)
        TileMap.surface=surface
        self.background=background
        self.fruits=[ pygame.image.load("./data/"+p).convert()  for p in os.listdir("./data/")   if p.startswith("fruit")]
        self.enemys=[ pygame.image.load("./data/"+p).convert()  for p in os.listdir("./data/")   if p.startswith("enemy")]
        self.step_count=0
        self.step_show=50
        self.has_enemy=False
        self.back=pygame.mixer.Sound(back)
        self.font=freetype.Font('./data/stsong.ttf',30)

        self.fruit_music=pygame.mixer.Sound("./data/gamefruit.mp3")

        self.fruit_count=10

        self.show_text=[]
        self.show_text_step=0
        self.show_text_size=8
        self.colors=list(np.random.randint(0,256,(10000,3)))

        toto=(self.row-2)*2+self.col*2
        self.wall_colors=rd.sample(self.colors,k=toto)


    def draw_fruit(self,k=10):
        if self.step_count%self.step_show==0:
            where=np.random.randint(0,2,self.row*self.col)
            self.where=[ (self.p2c(i),self.p2r(i)) for i in range(len(where))  if where[i]>0 and  self.ok(self.p2r(i),self.p2c(i))
                        and  np.any(np.array((self.p2r(i),self.p2c(i)))*self.cellsize >= np.array((cantsee,cantsee)) )]
            
            import random as rd
            enemys=[pos for img, pos in  self.show_enemys]
            self.where=[ w for  w in  self.where  if not ( w in enemys)]
            self.where=rd.sample(self.where,k=k)
            self.show_fruits=[(np.random.choice(self.fruits), pos) for  pos in self.where]
            self.fruits_pos=[tuple(p) for  _,p  in  self.show_fruits]

        [TileMap.surface.blit(fruit,np.array(rectxy)*self.cellsize)   for  fruit,rectxy in self.show_fruits]

        if self.step_count%self.fruit_count==0:
            self.fruit_music.play()


    def draw_enemy(self,k=20):
        if  not self.has_enemy:
            where=np.random.randint(0,2,self.row*self.col)
            where=[ i for i in range(len(where))  if where[i]>0 and  self.ok(self.p2r(i),self.p2c(i))  and
                   np.any(np.array((self.p2r(i),self.p2c(i)))*self.cellsize >= np.array((cantsee,cantsee)) ) ]
        
            self.where=rd.sample(where,k=k)
            self.show_enemys=[(np.random.choice(self.enemys), (self.p2c(pos),self.p2r(pos))) for  pos in self.where]
            self.has_enemy=True
            self.enemys_pos=[ tuple(w) for  img,w in self.show_enemys]

        [TileMap.surface.blit(enemy,np.array(rectxy)*self.cellsize)   for  enemy,rectxy in self.show_enemys]
       


    def draw_text(self,whosize=5):
        
        if  self.show_text_step%self.show_text_size==0:
            whosays=rd.sample(self.show_enemys,k=whosize)
            txts=rd.sample(says,k=whosize)
            # print(txts)
            # print(whosays)
            self.show_text.clear()
            for (who,rt),tt in zip(whosays,txts):
                text_img,_=self.font.render(tt,(255,255,255),(0,78,23))
                text_rect=text_img.get_rect()
                
                text_rect.center=(np.array(rt)*self.cellsize+np.array((0,-10)))
                #text_img.set_alpha(180)
                self.show_text.append((text_img,text_rect))
               
        [TileMap.surface.blit(text_img,text_rect)  for  text_img,text_rect in self.show_text if text_rect[0]>self.cellsize and text_rect[0]+text_img.get_width()<=TileMap.width-self.cellsize ]

        self.show_text_step+=1



    def  draw_wall(self):
        TileMap.surface.fill(self.background)
        color=tuple(rd.sample(self.colors,k=1))
        linewidth=1
        [pygame.draw.line(TileMap.surface,color,(0,self.cellsize*r),(TileMap.width,self.cellsize*r),linewidth)
         for  r in range(self.row)]
        [pygame.draw.line(TileMap.surface,color,(self.cellsize*c,0),(self.cellsize*c,TileMap.height),linewidth)
         for  c in range(self.col)]
        
        wall_color=tuple(rd.sample(self.colors,k=1))
        [ pygame.draw.rect(TileMap.surface,wall_color,(i*self.cellsize+1,1,self.cellsize-2,self.cellsize-2))   for  i in range(self.col)  ]
        [ pygame.draw.rect(TileMap.surface,wall_color,(i*self.cellsize+1, TileMap.height-self.cellsize+1 , self.cellsize-2,self.cellsize-2))   for  i in range(self.col)  ]
        [ pygame.draw.rect(TileMap.surface,wall_color,(1,i*self.cellsize+1,self.cellsize-2,self.cellsize-2))   for  i in range(self.row)  ]
        [ pygame.draw.rect(TileMap.surface,wall_color,(TileMap.width-self.cellsize+1,i*self.cellsize+1,self.cellsize-2,self.cellsize-2))   for  i in range(self.row)  ]




    def  water_wall(self):
        
        cnt=0
        [ pygame.draw.rect(TileMap.surface,tuple(self.wall_colors[(i+self.step_count)%len(self.wall_colors)]),(i*self.cellsize+1,1,self.cellsize-2,self.cellsize-2))   for  i in range(self.col)  ]
        
        cnt+=self.col

        [ pygame.draw.rect(TileMap.surface,tuple(self.wall_colors[(i+cnt+self.step_count)%len(self.wall_colors)]),(TileMap.width-self.cellsize+1,i*self.cellsize+1,self.cellsize-2,self.cellsize-2))   for  i in range(1,self.row)  ]
        
        cnt+=self.row-2
        
        [ pygame.draw.rect(TileMap.surface,tuple(self.wall_colors[(i+cnt+self.step_count)%len(self.wall_colors)]),(i*self.cellsize+1, TileMap.height-self.cellsize+1 , self.cellsize-2,self.cellsize-2))   for  i in range(self.col,0,-1)  ]
        
        cnt+=self.col

        [ pygame.draw.rect(TileMap.surface,tuple(self.wall_colors[(i+cnt+self.step_count)%len(self.wall_colors)]),(1,i*self.cellsize+1,self.cellsize-2,self.cellsize-2))   for  i in range(self.row,1,-1)  ]



    def  draw(self):
        #self.draw_wall()
        
        self.water_wall()
        self.draw_enemy(50)
        self.draw_fruit(100)
        self.draw_text()

        self.step_count+=1


    def  redrawline(self):
        colors=[(255,255,255),(255,242,0),(255,98,2)]
        color=tuple(rd.sample(colors,k=1))
        
        linewidth=1
        [pygame.draw.line(TileMap.surface,color,(0,self.cellsize*r),(TileMap.width,self.cellsize*r),linewidth)
         for  r in range(self.row)]
        [pygame.draw.line(TileMap.surface,color,(self.cellsize*c,0),(self.cellsize*c,TileMap.height),linewidth)
         for  c in range(self.col)]
        

    def  can_eate(self,pos):
        return tuple(pos) in self.fruits_pos
    
    def  ifdie(self,pos):
        return tuple(pos)  in  self.enemys_pos

    def take_fruit(self,pos):
        pos=tuple(pos)
        if   self.fruits_pos.count(pos)<1:
                return 
             
        index=self.fruits_pos.index(pos)
        self.fruits_pos.remove(self.fruits_pos[index])
        self.show_fruits.remove(self.show_fruits[index])
        
        
        
    def  play_back(self  ):
        self.back.play(-1)




says=quotes = [
    "小勇士，慢点儿！",
    "追上我，再说吧！",
    "你，太慢了！",
    "嘿，来追我呀！",
    "加油，小笨蛋！",
    "别摔了，哈哈！",
    "跑不动了吧？",
    "我，等你哦！",
    "快来，抓我呀！",
    "急啥，慢慢来！",
    "看你，气喘的！",
    "我躲，你追！",
    "小样儿，来吧！",
    "累了吧，哈哈！",
    "追不上，拜拜！",
    "你，太逗了！",
    "来，再快点！",
    "我闪，你抓？",
    "逗你玩呢！",
    "小短腿，快些！",
    "别急，我等你！",
    "你，能行吗？",
    "看招，我溜！",
    "哼，抓不着！",
    "加油，小勇士！",
    "你，真慢啊！",
    "我躲躲，你追追！",
    "哈哈，追不上！",
    "再来，继续追！",
    "逗你，开心下！",
    "小样，放弃吧！",
    "我溜，你急啥？",
    "你，太慢了！",
    "快点，别磨蹭！",
    "哈哈，抓我呀！",
    "来嘛，再快点！",
    "我躲，你来追！",
    "别急，慢慢来！",
    "小勇士，加油！",
    "你，抓不着！",
    "逗逗，你真逗！",
    "我闪，你追呀！",
    "哈哈，累了吧？",
    "你，放弃吧！",
    "再追，我等你！",
    "快点哦，小笨！",
    "我躲好，你来找！",
    "别急嘛，慢慢来！",
    "哼，你不行！",
    "加油追，小勇！"
]